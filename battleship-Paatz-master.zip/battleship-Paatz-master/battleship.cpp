/*-----------------------------------------------------------------------------
 *				HTBLA-Leonding / Class: 2AHIF
 *-----------------------------------------------------------------------------
 * Exercise Number: #exercise_number#
 * File:			battleship.c
 * Author(s):		Patrick Spisak
 * Due Date:		14.Juni.2018
 *-----------------------------------------------------------------------------
 * Description:
 * Program battleship
 *-----------------------------------------------------------------------------
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "battleship.h"

static char* filename1 = "battleship.my";;
static char* filename2 = "battleship.op";
static CellContent myGuesses[FIELDSIZE][FIELDSIZE] ;
static CellContent myField[FIELDSIZE][FIELDSIZE];
static CellContent otherField[FIELDSIZE][FIELDSIZE];

	void 	load_game ()
	{
		//filename1 = "battleship.my";
	//	filename2 = "battleship.op";
		FILE * fd1 = fopen(filename1,"r");
		FILE * fd2 = fopen(filename2,"r");
		for(int i = 0;i < FIELDSIZE;i++)
		{
			for(int r = 0; r < FIELDSIZE;r++)
			{
				fread(&myField[r][i], sizeof(int),1, fd1);
				myGuesses[r][i] = Unknown;
			}
		}

		for(int i = 0;i < FIELDSIZE;i++)
		{
			for(int r = 0; r < FIELDSIZE;r++)
			{
				fread(&otherField[r][i], sizeof(int),1, fd2);
			}
		}
	}

	CellContent 	get_shot (int row, int col)
	{
		if(row <= 9 && row >= 0 && col <= 9 && col >= 0)
		{
			if(myField[col][row] == 0)
			{
				return Water;
			}
			else
			{
				return Boat;
			}
		}

		return OutOfRange;
	}

	bool 	shoot (int row, int col)
	{
		if(row <= 9 &&  row >= 0 && col <= 9 && col >= 0)
		{
			if(otherField[col][row] == 0)
			{
				myGuesses[col][row] = Water;
			}

			else
			{
				myGuesses[col][row] = Boat;
				if(row-1 >= 0)
				{
					myGuesses[col][row-1] = Water;
				}
				if(row+1 <= 9)
				{
						myGuesses[col][row+1] = Water;
				}
				if(col +1 <= 9)
				{
						myGuesses[col+1][row] = Water;
				}

				if(col -1 >= 0)
				{
						myGuesses[col-1][row] = Water;
				}

				if(col-1 >= 0 && row -1 >= 0)
				{
					myGuesses[col-1][row-1] = Water;
				}
				if(col+1 <= 9 && row -1 >= 0)
				{
					myGuesses[col+1][row-1] = Water;
				}
				if(col+1 <= 9 && row +1 <= 9)
				{
					myGuesses[col+1][row+1] = Water;
				}
				if(col-1 >= 0 && row +1 <= 9)
				{
					myGuesses[col-1][row+1] = Water;
				}
			}
						return true;
		}
		return false;
	}

	CellContent 	get_my_guess (int row, int col)
	{
		if(row <= 9 &&  row >= 0 && col <= 9 && col >= 0)
		{
			if(myGuesses[col][row] == Water)
			{
				return  Water;
			}

			else if(myGuesses[col][row] == Boat)
			{
				return Boat;
			}

			else
			{
				return Unknown;
			}
		}

		return OutOfRange;

	}
